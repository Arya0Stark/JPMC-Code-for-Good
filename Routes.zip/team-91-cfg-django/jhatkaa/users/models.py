from django.db import models
from django.contrib.auth.models import User
from django.db import models
     
roles=[('Volunteer','Volunteer'),
('Citizen','Citizen'),
]

class UserProfile(models.Model):
    user = models.OneToOneField(User,on_delete=models.CASCADE)
    role = models.CharField(max_length=10,choices=roles,default='Citizen')
    phone_number = models.IntegerField(default=0)
    email=models.EmailField(unique=True)
    def __str__(self):
        return self.user.username

class Citizen(UserProfile):
    location=models.TextField()
    def __str__(self):
        return self.email
    
class Volunteer(UserProfile):
    pass
    def __str__(self):
        return self.email

class Campaign(models.Model):
    #picture=models.ImageField(upload_to='uploads/photos/')
    title = models.CharField(max_length = 50,null=False,blank=False)
    subject = models.CharField(max_length= 100)
    signatures_required = models.IntegerField(default=0)
    signatures_collected = models.IntegerField(default=0)
    body = models.CharField(max_length=3000)
    supporter = models.ManyToManyField(UserProfile)

    def __str__(self):
        return str(self.title)


class Message(models.Model):
    sender = models.ForeignKey(UserProfile,on_delete=models.CASCADE)
    to_campaign = models.ForeignKey(Campaign,on_delete=models.CASCADE)
    created = models.DateTimeField(auto_now_add=True)
    content = models.CharField(max_length=1000,null=True)

    def __str__(self):
        return str(self.sender.user.username)

    class Meta:
        ordering = ['created']

