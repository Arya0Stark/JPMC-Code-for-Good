from django.contrib import admin
from .models import UserProfile,Citizen,Volunteer,Campaign,Message

class AdminUserProfile(admin.ModelAdmin):
    list_display = ['user', 'role', 'email']

class AdminCitizen(admin.ModelAdmin):
    list_display = ['user', 'email','location']

class AdminVolunteer(admin.ModelAdmin):
    list_display = ['user', 'email']

class AdminCampaign(admin.ModelAdmin):
    list_display = ['title', 'subject', 'signatures_required','signatures_collected']


class AdminMessage(admin.ModelAdmin):
    list_display = ['sender', 'to_campaign', 'created','content']

# Register your models here.
admin.site.register(UserProfile,AdminUserProfile)
admin.site.register(Citizen,AdminCitizen)
admin.site.register(Volunteer,AdminVolunteer)
admin.site.register(Campaign,AdminCampaign)
admin.site.register(Message,AdminMessage)

