
from django.shortcuts import render, HttpResponseRedirect
# Create your views here.

# This Function Will Add new Item and Show All Items
def home(request):
    return render(request,'users/home.html')

def events(request):
    return render(request,'users/events.html')

def login(request):
    return render(request,'users/login.html')